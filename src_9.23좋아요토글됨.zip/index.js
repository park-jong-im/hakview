import React from 'react';
import ReactDOM from 'react-dom';
import ReviewMain from './components/Review/ReviewMain';

ReactDOM.render(
  <React.StrictMode>
    <ReviewMain />
  </React.StrictMode>,
  document.getElementById('root')
);
