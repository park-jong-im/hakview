import React from "react";

function Header() {
    return (
        <header>
            <h1>이곳은 헤더입니다.</h1>
        </header>
    );
}

export default Header;
