import React, { useState } from "react";
import { useHistory } from "react-router-dom";
import Avatar from '@mui/material/Avatar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button'; 
import ThumbUpAltSharpIcon from '@mui/icons-material/ThumbUpAltSharp';
import Footer from '../../Footer';   
import Header from '../../Header';



const containerStyle = {
  display: 'flex',
  alignItems: 'center', // 수직 가운데 정렬
};

const iconStyle = {
  marginLeft: 'auto', // 아이콘과 버튼 사이의 간격을 조절  
};


export default function NoticeBoardForm() {
  const history = useHistory(); 

  const [isLiked, setIsLiked] = useState(false); //좋아요버튼 토글

  const toggleLike = () => {
    setIsLiked(!isLiked); 
  };

  const iconColor = isLiked ? '#0288d1' : '#808080'; //좋아요 버튼 컬러


  const handleGoToList = () => {
    history.push('/NoticeBoardMain'); // 목록으로 가기 버튼
  };


  return (
    <>
    <Header/>
    <div style={{ border: '1px solid #ccc', width: '1000px', borderRadius: '10px', margin: '80px auto' }}>
    <div style={{ border: '1px solid white', width: '900px', margin: '40px auto' }}>
    <Typography variant="h5" style={{ textAlign: 'center', marginBottom: '20px', fontWeight: 'bold' }}>
      자유 게시판
    </Typography>    
    <hr style={{ width: '900px', border: '0', marginBottom: '20px', borderBottom: '1px solid #ccc'}} />
    <Typography variant="h6" style={{ marginBottom: '20px', color: '#3f51b5', fontWeight: 'bold' }}>
      [지방직 공무원 합격수기] 모르고 시작한 공무원 시험, 합격할 수 있었던 이유
    </Typography>     
    <div style={{ display: 'flex', alignItems: 'center' }}>
      <Avatar
        src="/broken-image.jpg"
        style={{ width: '30px', height: '30px', marginRight: '10px' }}
      />
      <Typography variant="body1" style={{ color: '#666', flexBasis:'50%', flexGrow: 1 }}>
          작성자세미쿤
      </Typography> 
      <Typography variant="body1" style={{ color: '#666'}}>
        조회 |
      </Typography> 
      <Typography variant="body1" style={{ color: '#666', flexBasis:'1%', flexGrow: 0.5 }}>
        16015
      </Typography> 
      <Typography variant="body1" style={{ color: '#666'}}>
        추천 |
      </Typography> 
      <Typography variant="body1" style={{ color:'#666', flexBasis:'1%', flexGrow : 0.2 }}>
          45 
      </Typography> 
      <Typography variant="body1" style={{ color:'#666', flexBasis:'1%', flexGrow : 0.5}}>
          날짜 | 
      </Typography>
      <Typography variant="body1" style={{color:'#666', marginLeft:'auto'}}>          
          {new Date().toLocaleDateString()}
        </Typography>
    </div>

  <hr style={{ width: '900px', border: '0', marginTop: '20px', marginBottom: '20px', borderBottom: '1px solid #ccc'}} />
  <Typography variant="body1" style={{marginBottom: '30px', color: '#666'}}>
      ▲ 9급 공무원 시험, 단순한 엉덩이 싸움이 아닌… 합격전략이 중요<br/>
      각 수업을 2, 3회독씩 하고 나서는 각 시험과목을 혼자서 1회독 했습니다.<br/> 
      국어, 국사, 영어는 혼자서 1회독씩 했고, 행정법은 특강을 들어서 눈에 익숙하게 만들었습니다. <br/>
      시험을 한 달 앞두고선 국어, 영어는 오전에 모의고사 1회씩을 매일 풀었습니다. <br/>
      오후에는 행정법과 국사를 공부하는 식으로 매일 3과목 이상씩 공부하려고 했습니다.<br/> 
      사회복지는 다른 선생님의 인강으로 들었습니다. 그리고 시험 두 달 전부터 중요한 부분만 보고, 기출문제를 풀었습니다.<br/>
      제 부족한 글을 읽어주셔서 감사합니다. 모두들 간절히 바라시는 공무원의 꿈을 이루시길 바랍니다. ^^
     </Typography>
     <hr style={{ width: '900px', border: '0', marginTop: '20px', marginBottom: '20px', borderBottom: '1px solid #ccc'}} />
     <div style={containerStyle}>
          <Button
            type="submit"
            variant="contained"
            color="primary"
            className="button"
            onClick={handleGoToList}
            sx={{
              backgroundImage: 'linear-gradient(45deg, #9370DB 30%, #0288d1 90%)',
              color: 'white',
              fontSize: '15px',
              width: 'auto',
            }}
            
          >
            &laquo; 목록으로 가기
          </Button>
          <ThumbUpAltSharpIcon
              style={{ ...iconStyle, color: iconColor }} 
              onClick={toggleLike} 
            />
          &nbsp;0
      </div>    
    </div>    
  </div>
  <Footer/>  
  </>
);
}