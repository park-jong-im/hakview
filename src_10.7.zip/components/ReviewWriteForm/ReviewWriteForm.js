import React from 'react';
import Footer from '../../Footer';
import Header from '../../Header';
import ReviewWrite from './ReviewWrite';

export default function ReviewWriteForm() {
  return (
    <>
      <Header />
      <ReviewWrite />
      <Footer />
    </>
  );
}
