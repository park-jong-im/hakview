import * as React from 'react';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import ListSubheader from '@mui/material/ListSubheader';
import ChecklistIcon from '@mui/icons-material/Checklist';
import AccountBoxIcon from '@mui/icons-material/AccountBox';
import PersonOffIcon from '@mui/icons-material/PersonOff';

export const mainListItems = (
  <React.Fragment>
    <ListSubheader component="div" inset sx={{ fontSize: '1.2rem', textAlign: 'left', fontWeight:'bold' }} >
       마이페이지
    </ListSubheader> 
  </React.Fragment>
);

export const secondaryListItems = (
  <React.Fragment>
 <ListItemButton>
      <ListItemIcon>
        <AccountBoxIcon />
      </ListItemIcon>
      <ListItemText primary="회원정보 수정" />
    </ListItemButton>
    <ListItemButton>
      <ListItemIcon>
      <ChecklistIcon />
      </ListItemIcon>
      <ListItemText primary="내가 찜한 목록" />
    </ListItemButton>
    <ListItemButton>
      <ListItemIcon>
        <PersonOffIcon />
      </ListItemIcon>
      <ListItemText primary="계정 탈퇴" />
    </ListItemButton>
  </React.Fragment>
);