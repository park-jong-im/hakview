import React, { useState } from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Pagination from '@mui/material/Pagination';
import Button from '@mui/material/Button'; 
import Grid from '@mui/material/Grid';
import { Link } from 'react-router-dom'; 
import NoticeBoardForm from './NoticeBoardForm';

function createData(no, title, author, date, counts, likes) {
  return { no, title, author, counts, date, likes};
}

const initialRows = [
  createData('1', '공부잘하는 비법 알고싶어요', '블랙핑크', '2003.09.26', 24, 4),
  createData('2', '이렇게만 하면 서울대간다 나만의 비법', '뉴진스', '2003.09.26', 37, 10),
  createData('3', '이때 아니면 언제 공부하니', '공부벌레', '2003.09.26', 24, 6),
  createData('4', '정말 모르겠어요 수학잘하시는분', '꼴찌', '2003.09.26', 67, 4),
  createData('5', '안녕하세요', '하바드갈래', '2003.09.26', 49, 3),
  createData('6', '공부잘하는 비법 알고싶어요', '블랙핑크', '2003.09.26', 24, 4),
  createData('7', '이렇게만 하면 서울대간다 나만의 비법', '뉴진스', '2003.09.26', 37, 10),
  createData('8', '이때 아니면 언제 공부하니', '공부벌레', '2003.09.26', 24, 6),
  createData('9', '정말 모르겠어요 수학잘하시는분', '꼴찌', '2003.09.26', 67, 4),
  createData('10', '안녕하세요', '하바드갈래', '2003.09.26', 49, 3),
  createData('11', '공부잘하는 비법 알고싶어요', '블랙핑크','2003.09.26', 24, 4),
  createData('12', '이렇게만 하면 서울대간다 나만의 비법', '뉴진스', '2003.09.26',37, 10),
  createData('13', '이때 아니면 언제 공부하니', '공부벌레', '2003.09.26', 24, 6),
  createData('14', '정말 모르겠어요 수학잘하시는분', '꼴찌', '2003.09.26', 67, 4),
  createData('15', '안녕하세요', '하바드갈래', '2003.09.26',49, 3),
  createData('16', '공부잘하는 비법 알고싶어요', '블랙핑크', '2003.09.26', 24, 4),
  createData('17', '이렇게만 하면 서울대간다 나만의 비법', '뉴진스', '2003.09.26', 37, 10),
  createData('18', '이때 아니면 언제 공부하니', '공부벌레', '2003.09.26', 24, 6),
  createData('19', '정말 모르겠어요 수학잘하시는분', '꼴찌', '2003.09.26', 67, 4),
  createData('20', '안녕하세요', '하바드갈래', '2003.09.26', 49, 3),
];

function NoticBoardMain() {
  const [rows, setRows] = React.useState(initialRows);
  const [page, setPage] = React.useState(1);
  const [selectedItem, setSelectedItem] = useState(null); 
  const itemsPerPage = 10; // 한 페이지 당 아이템 수

  // 페이지 변경 시 데이터 업데이트
  const handlePageChange = (event, newPage) => {
    setPage(newPage);
    
    const startIndex = (newPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;

    const newRows = initialRows.slice(startIndex, endIndex);
    setRows(newRows);
  };

  return (    
    <div style={{ border: '1px solid #ccc', width: '900px', borderRadius: '10px', margin: '80px auto' }}>
      <h2 style={{ textAlign: 'center', marginTop: '50px', marginBottom: '40px'}}>자유 게시판</h2>
      <TableContainer component={Paper} sx={{ width: 800, margin: '0 auto' }}>
      <Table sx={{ maxWidth: 800, margin: '5px auto'}} aria-label="simple table">
      <TableHead sx={{
          backgroundImage: 'linear-gradient(45deg, rgba(147, 112, 219, 0.5) 40%, rgba(2, 136, 209, 0.5) 90%)',
          color: 'white',
          fontSize: '15px',
          width: 'auto',
        }}>
            <TableRow>
            <TableCell align="center" sx={{ fontWeight: 'bold', color: '#673ab7'}}>번호</TableCell>
            <TableCell align="center" sx={{ fontWeight: 'bold', color: '#673ab7'}}>제목</TableCell>
            <TableCell align="center" sx={{ fontWeight: 'bold', color: '#673ab7'}}>작성자</TableCell>
            <TableCell align="center" sx={{ fontWeight: 'bold', color: '#673ab7'}}>날짜</TableCell>
            <TableCell align="center" sx={{ fontWeight: 'bold', color: '#673ab7'}}>조회</TableCell>
            <TableCell align="center" sx={{ fontWeight: 'bold', color: '#673ab7'}}>추천</TableCell>
          </TableRow>
        </TableHead >
        <TableBody>
          {rows.map((row) => (
            <TableRow
              key={row.no}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}              
              style={{ cursor: 'pointer' }}
            >
              <TableCell align="center" component="th" scope="row">
                {row.no}
              </TableCell>
              <TableCell align="left">
                <Link to={`/NoticeBoardForm/${row.no}`}>{row.title}</Link>
              </TableCell>
              <TableCell align="center">{row.author}</TableCell>
              <TableCell align="center">{row.date}</TableCell>
              <TableCell align="center">{row.counts}</TableCell>
              <TableCell align="center">{row.likes}</TableCell>
            </TableRow>
          ))}
        </TableBody>
         {/* ... existing code ... */}
      {selectedItem && (
        <div>      
          <NoticeBoardForm item={selectedItem} />
        </div>
      )}
      </Table>
     </TableContainer>
     <Grid container spacing={2} alignItems="center" sx={{ justifyContent: 'center', marginTop: '30px', marginBottom: '30px' }}>
        <Grid item sx={{ marginLeft: '250px' }}>
        <Pagination count={Math.ceil(initialRows.length / itemsPerPage)} variant="outlined" color="secondary" page={page} onChange={handlePageChange} />
        </Grid>
        <Grid item sx={{ display: 'flex', justifyContent: 'flex-end', marginLeft: '200px' }}>
        <Link to="/NoticeBoardWrite">
          <Button
            type="submit"
            variant="contained"
            color="primary"
            className="button"
            sx={{
              backgroundImage: 'linear-gradient(45deg, #9370DB 30%, #0288d1 90%)',
              color: 'white',
              fontSize: '15px',
              width: 'auto',
            }}
          >
            글쓰기
          </Button>
          </Link>
        </Grid>
      </Grid>
    </div>
  );
}

export default NoticBoardMain;