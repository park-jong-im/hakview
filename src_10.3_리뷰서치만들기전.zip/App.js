import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import ReviewMain from './components/Review/ReviewMain';
import ReviewWrite from './components/ReviewWriteForm/ReviewWrite';
import NoticeBoardMain from '../src/components/NoticeBoard/NoticeBoardMain';
import NoticeBoardWrite from '../src/components/NoticeBoard/NoticeBoardWrite';
import NoticeBoardForm from './components/NoticeBoard/NoticeBoardForm';

function App() {
  return (
    <Router>
      <Switch>
        <Route exact path="/" component={ReviewMain} />
        <Route path="/ReviewWrite" component={ReviewWrite} /> 
        <Route path="/NoticeBoardMain" component={NoticeBoardMain} /> 
        <Route path="/NoticeBoardWrite" component={NoticeBoardWrite} /> 
        <Route path="/NoticeBoardForm/:postId" component={NoticeBoardForm} />           
      </Switch>
    </Router>
  );
}

export default App;