import React from "react";

function Footer() {
    return (
        <footer>
            <p>이곳은 푸터입니다.</p>
        </footer>
    );
}

export default Footer;
