import React from 'react';
import { Switch, Route } from 'react-router-dom';
import ReviewMain from './components/Review/ReviewMain';
import ReviewForm from './components/ReviewWriteForm/ReviewForm';
import { createReview, handleCreateSuccess } from './api';

function App() {
    return (
        <Switch>
            <Route exact path="/" component={ReviewMain} />
            <Route path="/ReviewForm" component={ReviewForm}/>
        </Switch>
    );
}

export default App;
